package com.example.plakatakip

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.ToneGenerator
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("plates", MODE_PRIVATE) }
    private val plates = linkedSetOf<String>()
    private val history = mutableListOf<String>()
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private lateinit var scanButton: Button
    private var continuous = true
    @Volatile private var scanRequested = false
    private var lastAlertAt = 0L
    private var lastAlertPlate = ""
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { importXlsx(it) } }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startCamera() else status.text = "Kamera izni verilmedi." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = prefs.getStringSet("items", null)
        if (saved == null) {
            plates.addAll(listOf(
                "16ED440","16LDR79","16BVJ934","16BVU084","10ADD500","17PF925","16RAC06","16BMZ41","16RJ084","16AED242","16AGR10","16BPB010","16KGC44","16BDK48","16BGN365","16GG372","16BOS306","45ARB309","16BCB28","77BM231","54YL502","16LKA79","16SGV52","16BMP015","16AYB779","16BIJ765","10AUE225","10ALM134","10AKY773","10AJG661","10AJH156","10AKY518","10AHV551","17AHC829","16MRT44","16AOV224","45UA3640","16BCT936","16BAU277","16AVR648","10PK585","27F5732","16GB371","16AUJ111","34PLL767","16BHY177"
            ))
            savePlates()
        } else plates.addAll(saved)
        buildHome()
    }

    private fun savePlates() { prefs.edit().putStringSet("items", plates.toSet()).apply() }
    private fun normalize(s: String) = s.uppercase().replace("İ", "I").replace("ı", "I").replace("Ş", "S").replace("Ğ", "G").replace("Ü", "U").replace("Ö", "O").replace("Ç", "C").replace(Regex("[^A-Z0-9]"), "")

    private fun buildHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20); setBackgroundColor(Color.rgb(246,248,251)) }
        root.addView(TextView(this).apply { text = "PLAKA TAKİP & ALARM"; textSize = 23f; setTextColor(Color.rgb(16,42,67)); gravity = Gravity.CENTER; setPadding(0,10,0,18) })
        root.addView(TextView(this).apply { text = "Excel listesi + manuel kayıt + canlı kamera"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(0,0,0,20) })
        addButton(root, "📷  KAMERA İLE TARA") { showCamera() }
        addButton(root, "📊  EXCEL DOSYASI YÜKLE (.xlsx)") { importFile.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "*/*")) }
        addButton(root, "✍️  ELLE PLAKA EKLE") { addPlateDialog() }
        addButton(root, "📋  PLAKA LİSTESİNİ GÖR / DÜZENLE") { showPlateList() }
        addButton(root, "🕘  TESPİT GEÇMİŞİ") { showHistory() }
        status = TextView(this).apply { text = "Kayıtlı plaka: ${plates.size}\nAlarm: ses + titreşim | Tekrar aralığı: 30 saniye"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(8,22,8,0) }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; isAllCaps = false; textSize = 15f; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 9 })
    }

    private fun addPlateDialog() {
        val input = EditText(this).apply { hint = "Örn. 34ABC123"; inputType = android.text.InputType.TYPE_CLASS_TEXT; filters = arrayOf(android.text.InputFilter.AllCaps()) }
        val note = EditText(this).apply { hint = "Açıklama (isteğe bağlı)" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,8,24,0); addView(input); addView(note) }
        AlertDialog.Builder(this).setTitle("Yeni plaka ekle").setView(box).setPositiveButton("Kaydet") { _, _ ->
            val p = normalize(input.text.toString())
            if (isPlausiblePlate(p)) { plates.add(p); savePlates(); status.text = "Kayıtlı plaka: ${plates.size}"; Toast.makeText(this,"$p kaydedildi",Toast.LENGTH_SHORT).show() }
            else Toast.makeText(this,"Geçerli bir plaka girin.",Toast.LENGTH_LONG).show()
        }.setNegativeButton("İptal",null).show()
    }

    private fun isPlausiblePlate(p: String) = Pattern.matches("^[0-8][0-9][A-Z]{1,3}[0-9]{2,4}$", p)

    private fun showPlateList() {
        if (plates.isEmpty()) { Toast.makeText(this,"Henüz plaka eklenmedi.",Toast.LENGTH_SHORT).show(); return }
        val items = plates.toTypedArray()
        AlertDialog.Builder(this).setTitle("Kayıtlı plakalar (${items.size})").setItems(items) { _, which ->
            val selected = items[which]
            AlertDialog.Builder(this).setMessage("$selected kaydını silmek istiyor musunuz?").setPositiveButton("Sil") { _, _ -> plates.remove(selected); savePlates(); status.text = "Kayıtlı plaka: ${plates.size}" }.setNegativeButton("Vazgeç",null).show()
        }.setPositiveButton("Kapat",null).show()
    }

    private fun showHistory() {
        val body = if (history.isEmpty()) "Bu oturumda henüz eşleşme bulunmadı." else history.asReversed().joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Tespit geçmişi").setMessage(body).setPositiveButton("Kapat",null).show()
    }

    private fun showCamera() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply { layoutParams = LinearLayout.LayoutParams(-1,0,1f) }
        layout.addView(preview)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,10,12,14); setBackgroundColor(Color.WHITE) }
        status = TextView(this).apply { text = "Kamera hazırlanıyor…"; textSize = 16f; setTextColor(Color.BLACK); gravity = Gravity.CENTER; setPadding(4,8,4,8) }
        controls.addView(status)
        scanButton = Button(this).apply { text = "Mod: Sürekli tarama (değiştir)"; isAllCaps = false; setOnClickListener { continuous = !continuous; text = if (continuous) "Mod: Sürekli tarama (değiştir)" else "Mod: Dokunarak tara (değiştir)"; status.text = if (continuous) "Sürekli tarama açık" else "Plakaya yöneltip TARA düğmesine basın" } }
        controls.addView(scanButton)
        val once = Button(this).apply { text = "ŞİMDİ TARA"; setOnClickListener { scanRequested = true; status.text = "Plaka aranıyor…" } }
        controls.addView(once)
        val back = Button(this).apply { text = "Ana menü"; setOnClickListener { scanRequested = false; buildHome() } }
        controls.addView(back)
        layout.addView(controls)
        setContentView(layout)
        scanRequested = false
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                if (!continuous && !scanRequested) { proxy.close(); return@setAnalyzer }
                if (!continuous) scanRequested = false
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                recognizer.process(image).addOnSuccessListener { result ->
                    val raw = result.text
                    val compact = normalize(raw)
                    val match = plates.firstOrNull { p -> compact.contains(p) || raw.split(Regex("\\s+")).any { normalize(it) == p } }
                    runOnUiThread {
                        if (match != null) { status.text = "⚠ EŞLEŞME BULUNDU: $match"; alertMatch(match) }
                        else if (continuous) status.text = "Taranıyor… Kayıtlı plaka: ${plates.size}"
                    }
                }.addOnCompleteListener { proxy.close() }
            }
            try { provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis) }
            catch (e: Exception) { status.text = "Kamera başlatılamadı: ${e.localizedMessage}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun alertMatch(plate: String) {
        val now = System.currentTimeMillis()
        if (plate == lastAlertPlate && now - lastAlertAt < 30_000) return
        lastAlertPlate = plate; lastAlertAt = now
        history.add("$plate — ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale("tr")).format(java.util.Date())}")
        try { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200) } catch (_: Exception) {}
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE)) else @Suppress("DEPRECATION") vibrator.vibrate(700)
    }

    private fun importXlsx(uri: Uri) {
        try {
            val imported = readXlsx(uri).map { normalize(it) }.filter { isPlausiblePlate(it) }.toSet()
            val before = plates.size; plates.addAll(imported); savePlates()
            status.text = "Excel aktarıldı. Yeni: ${plates.size-before}, toplam: ${plates.size}"
            Toast.makeText(this,"${imported.size} geçerli plaka içe aktarıldı.",Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this,"Excel okunamadı: ${e.localizedMessage}",Toast.LENGTH_LONG).show() }
    }

    // XLSX is a ZIP containing sharedStrings.xml and sheet XML. Reads cell values without a network service.
    private fun readXlsx(uri: Uri): List<String> {
        val entries = mutableMapOf<String, ByteArray>()
        contentResolver.openInputStream(uri).use { input ->
            val zip = ZipInputStream(input!!)
            var entry: ZipEntry? = zip.nextEntry
            while (entry != null) { if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name.startsWith("xl/worksheets/sheet"))) entries[entry.name] = zip.readBytes(); zip.closeEntry(); entry = zip.nextEntry }
            zip.close()
        }
        fun parseXml(bytes: ByteArray): List<Pair<String,String>> {
            val parser = XmlPullParserFactory.newInstance().newPullParser(); parser.setInput(bytes.inputStream(),"UTF-8")
            val out = mutableListOf<Pair<String,String>>(); var cellType = ""; var inCell = false; var inValue = false; var value = StringBuilder(); var cell = ""
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when(event) {
                    XmlPullParser.START_TAG -> when(parser.name) {
                        "c" -> { inCell = true; cellType = parser.getAttributeValue(null,"t") ?: ""; cell = parser.getAttributeValue(null,"r") ?: ""; value = StringBuilder() }
                        "v", "t" -> if (inCell) inValue = true
                    }
                    XmlPullParser.TEXT -> if (inCell && inValue) value.append(parser.text)
                    XmlPullParser.END_TAG -> when(parser.name) {
                        "v", "t" -> inValue = false
                        "c" -> { out.add(cellType to value.toString()); inCell = false }
                    }
                }; event = parser.next()
            }; return out
        }
        val shared = entries["xl/sharedStrings.xml"]?.let { bytes ->
            val parser = XmlPullParserFactory.newInstance().newPullParser(); parser.setInput(bytes.inputStream(),"UTF-8"); val strings= mutableListOf<String>(); val b=StringBuilder(); var inSi=false
            var ev=parser.eventType; while(ev!=XmlPullParser.END_DOCUMENT){ if(ev==XmlPullParser.START_TAG && parser.name=="si"){inSi=true;b.setLength(0)} else if(ev==XmlPullParser.START_TAG && parser.name=="t" && inSi){ /* text follows */ } else if(ev==XmlPullParser.TEXT && inSi){b.append(parser.text)} else if(ev==XmlPullParser.END_TAG && parser.name=="si"){strings.add(b.toString());inSi=false}; ev=parser.next() }; strings
        } ?: emptyList()
        val sheet = entries.filterKeys { it.startsWith("xl/worksheets/sheet") }.toSortedMap().values.firstOrNull() ?: error("Çalışma sayfası bulunamadı")
        return parseXml(sheet).mapNotNull { (type, value) -> if (type == "s") shared.getOrNull(value.toIntOrNull() ?: -1) else value }.filter { it.isNotBlank() }
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown(); recognizer.close() }
}

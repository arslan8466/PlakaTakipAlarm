# Plaka Takip & Alarm (Android kaynak projesi)

Bu proje Android Studio ile derlenmek üzere hazırlanmış bir Kotlin uygulama başlangıç sürümüdür.

## Özellikler
- XLSX dosyasından plaka içe aktarma (cihaz üzerinde, internet gerektirmeden)
- Manuel plaka ekleme
- Yerel cihazda kayıtlı plaka listesi
- CameraX canlı kamera
- ML Kit Latin metin tanıma ile kameradan OCR
- Sürekli tarama / manuel tetikleme arayüzü
- Eşleşmede ses + titreşim, aynı plaka için 30 saniye tekrar bastırma
- Oturum içi tespit geçmişi

## Derleme
1. Android Studio güncel sürümünü açın.
2. Bu klasörü `Open` ile açın.
3. Gradle senkronizasyonunu tamamlayın.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin.
5. Telefonda uygulamayı açıp kamera iznini verin.

## Önemli test notları
Bu kaynak proje bu çalışma ortamında Android SDK/Gradle bulunmadığı için derlenip cihazda test edilemedi. Gerçek araç plakalarında OCR performansı kamera mesafesi, açı, ışık ve plaka netliğine bağlıdır. Bu sürüm OCR metnini kayıtlı plakalarla karşılaştıran bir prototiptir; ticari/operasyonel kullanımdan önce farklı telefonlarda ve gerçek koşullarda test edilmelidir. Arka planda/gizli kamera taraması yapmaz; kamera ekranı açıkken çalışır.

## Veri güvenliği
Plaka listesi cihazdaki uygulama depolamasında tutulur. Excel içe aktarma ve OCR için uzak sunucuya veri gönderilmez.
